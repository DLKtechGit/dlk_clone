// {
//     "Length": 2,
//     "Results": [
//         {
//             "customerDetails": {
//                 "name": "DLK",
//                 "email": "dlk@gmail.com",
//                 "phoneNumber": "907802d96",
//                 "qrcode": []
//             },
//             "_id": "661371a12e9675c36abaa0ec",
//             "customerId": "660fc652e23cf1b741d2c5d8",
//             "technicians": [
//                 {
//                     "technicianId": "660fc6e1e23cf1b741d2c5ea",
//                     "tasks": [
//                         {
//                             "serviceName": "1111111",
//                             "companyName": "Company Name",
//                             "startDate": "2024-04-06T10:00:00.000Z",
//                             "endtime": "2024-04-06T12:00:00.000Z",
//                             "starttime": "2024-04-06T09:00:00.000Z",
//                             "description": "Task Description",
//                             "status": "completed",
//                             "_id": "661371a12e9675c36abaa0ee"
//                         }
//                     ],
//                     "_id": "661371a12e9675c36abaa0ed"
//                 }
//             ],
//             "__v": 0
//         },
//         {
//             "customerDetails": {
//                 "name": "lavanya",
//                 "email": "lavanya@gmail.com",
//                 "phoneNumber": "9078029996",
//                 "qrcode": []
//             },
//             "_id": "661371dc2e9675c36abaa0f3",
//             "customerId": "6610de4298d3508b693e952a",
//             "technicians": [
//                 {
//                     "technicianId": "660fc6e1e23cf1b741d2c5ea",
//                     "tasks": [
//                         {
//                             "serviceName": "1111111",
//                             "companyName": "Company Name",
//                             "startDate": "2024-04-06T10:00:00.000Z",
//                             "endtime": "2024-04-06T12:00:00.000Z",
//                             "starttime": "2024-04-06T09:00:00.000Z",
//                             "description": "Task Description",
//                             "status": "completed",
//                             "_id": "661371dc2e9675c36abaa0f5"
//                         },
//                         {
//                             "serviceName": "Bird",
//                             "companyName": "Company Name",
//                             "startDate": "2024-04-06T10:00:00.000Z",
//                             "endtime": "2024-04-06T12:00:00.000Z",
//                             "starttime": "2024-04-06T09:00:00.000Z",
//                             "description": "Task Description",
//                             "status": "completed",
//                             "_id": "6613859880175dcf85fd1aae"
//                         }
//                     ],
//                     "_id": "661371dc2e9675c36abaa0f4"
//                 }
//             ],
//             "__v": 1
//         }
//     ]
// }