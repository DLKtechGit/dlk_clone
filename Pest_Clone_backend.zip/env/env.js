const env = {   
    SECRET_TOKEN: "Pest123",
    DB_CONNECTION_URL: 'mongodb+srv://pestpatrol:Pest12345@cluster0.9zo8ck5.mongodb.net/dlk_clone?retryWrites=true&w=majority&appName=Cluster0'
    // DB_CONNECTION_URL:"mongodb://pestpatrol:Pest12345@ac-dqbhjfs-shard-00-00.9zo8ck5.mongodb.net:27017,ac-dqbhjfs-shard-00-01.9zo8ck5.mongodb.net:27017,ac-dqbhjfs-shard-00-02.9zo8ck5.mongodb.net:27017/?ssl=true&replicaSet=atlas-7n9anp-shard-0&authSource=admin&retryWrites=true&w=majority&appName=Cluster0"
}
module.exports = env; 
             

// mongodb+srv://pestpatrol:Pest12345@cluster0.9zo8ck5.mongodb.net/test?retryWrites=true&w=majority&appName=Cluster0

 