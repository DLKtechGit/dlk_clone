// const mongoose = require("mongoose");

// const reportSchema = new mongoose.Schema({
//    customerName: {
//       type: String,
//       required: true
//    },
//    serviceName: {
//       type: String,
//       required: true
//    },
//    pdf: {
//       data: Buffer, // Storing PDF as a Buffer
//       contentType: String // Mime type of the PDF
//    },
//    date: {
//       type: Date,
//       default: Date.now
//    }
// });

// const ReportModel = mongoose.model("Reports", reportSchema);

// module.exports = ReportModel;
